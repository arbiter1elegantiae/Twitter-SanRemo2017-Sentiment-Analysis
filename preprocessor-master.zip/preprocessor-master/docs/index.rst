.. preprocessor documentation master file, created by
   sphinx-quickstart on Tue Jan 26 00:04:16 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Preprocessor
========================================

Preprocessor's goal is to make preprocessing tweet data easy. It gets you what you need with a clean syntax.

    >>> import preprocessor
    >>> cleaned_tweet = preprocessor.clean("Preprocessor is #awesome https://github.com/s/preprocessor")
     Preprocessor is

.. toctree::
   :maxdepth: 2
